# BlueWorks Field Forms

Mobile-first field reporting app for BlueWorks LLC crews. Runs entirely in the browser — no server, no login, no build step. Reports are saved as drafts on the device and sent to the office as a PDF via the phone's print/share sheet.

## Forms included

| Form | What it captures |
|---|---|
| Daily Report | Technicians, work items, delays, field sketch, photos |
| Pipe Lining Material List | Truck-load checklist by category with quantities and sizes |
| Material & Supply List | Commercial plumbing order by section (DWV, water, valves, gas, fixtures, hangers, consumables) |
| Piping Inspection Report | Building info plus pipe-by-pipe size, material, length, laterals, condition |
| Weekly Vehicle Pre-Trip Checklist | Exterior, under-hood, safety gear, driver/supervisor sign-off |
| Daily Field Report | Crew hours, work areas, look-ahead, issues, urgent office actions, materials needed, coordination |
| Equipment Check | Crew equipment count vs. standard kit, with asset numbers |
| Access Cut Photo Report | Before / after-cut / after-repair photo log per access point |

## Running it

**Option A – open the file.** Download or clone the repo and open `index.html` in any modern browser. Everything (React, runtime, logo) is vendored, so it works offline.

**Option B – GitHub Pages.** In the repo go to *Settings → Pages*, set the source to the `main` branch, root folder. The app will be served at `https://<user>.github.io/<repo>/`. Crews can add that URL to their phone's home screen.

**Option C – single file.** `dist/Field_Report_Forms_Blueworks.html` is the original self-contained export. Email or AirDrop that one file and it opens with no other assets.

## How it works

- `index.html` – the app: every form's markup plus the `Component` logic at the bottom of the file (options lists, default emails, state handling, print/send flow).
- `assets/dc-runtime.js` – the small template runtime that binds the markup to the logic (generated; don't edit).
- `assets/material-categories.js` – the item list for the Pipe Lining Material List. Edit this to add/remove stock items.
- `assets/blueworks-logo.png` – header and print logo.
- `vendor/` – React 18.3.1 UMD builds, loaded locally instead of from a CDN.

Drafts, sent reports and settings live in the browser's `localStorage` (`bw_reports_v1`, `bw_settings_v1`, `bw_session_v1`). Clearing site data clears the reports.

## Common edits

- **Manager emails** – change `DEFAULT_EMAILS` in `index.html` (users can also override them in the app's Settings screen).
- **Dropdown / chip options** – the `static ..._OPTIONS` arrays at the top of the `Component` class in `index.html`.
- **Standard equipment kit** – `EQUIP_TYPES` in `index.html` (`target` is the expected count per truck).
- **Material list items** – `assets/material-categories.js`.

## Uploading to GitHub

```bash
git init
git add .
git commit -m "Initial commit: BlueWorks Field Forms"
git branch -M main
git remote add origin https://github.com/<user>/<repo>.git
git push -u origin main
```

Or on github.com: create a new repository, choose *uploading an existing file*, and drag the contents of this folder in.
