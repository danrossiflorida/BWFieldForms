window.MATERIAL_CATEGORIES = [
  { title: "Liner", items: [
    { name: "Felt liner 2\"", unit: "ft" },
    { name: "Felt liner 3\"", unit: "ft" },
    { name: "Felt liner 4\"", unit: "ft" },
    { name: "Felt liner 6\"", unit: "ft" },
    { name: "Felt liner 8\"", unit: "ft" },
    { name: "Liner thickness (mm)", unit: "mm" },
    { name: "Pre-liner / sleeve", unit: "ft" },
    { name: "Lateral / T-liner kits", unit: "ea" },
    { name: "Calibration hose / bladder 2\"\u20133\"", unit: "ft" },
    { name: "Calibration hose / bladder 4\"\u20136\"", unit: "ft" },
    { name: "Air / pull ends", unit: "ea" }
  ]},
  { title: "Resin & Wet-Out", items: [
    { name: "Epoxy resin \u2014 Part A", unit: "gal" },
    { name: "Hardener \u2014 Part B", unit: "gal" },
    { name: "Epoxy cartridges", unit: "ea" },
    { name: "Mixing buckets", unit: "ea" },
    { name: "Bucket liners", unit: "ea" },
    { name: "Mixing paddles", unit: "ea" },
    { name: "Digital scale", unit: "ea" }
  ]},
  { title: "Prep & Cleaning", items: [
    { name: "Descaling chain heads", unit: "ea", hasSizes: true, sizeOptions: ["2\"","3\"","4\"","5/6\""] },
    { name: "Cable machine / flex shaft", unit: "ea", hasDesc: true },
    { name: "CCTV camera + reel", unit: "ea", hasDesc: true },
    { name: "Pipe plugs / test balls (by size)", unit: "ea", hasDesc: true }
  ]},
  { title: "Reinstatement", items: [
    { name: "Robotic cutter", unit: "ea" },
    { name: "Cutter bits / blades", unit: "ea" },
    { name: "Lateral reinstatement cutter", unit: "ea", hasDesc: true },
    { name: "Grinder + discs", unit: "ea" }
  ]},
  { title: "Access & Plumbing", items: [
    { name: "Cleanout caps / plugs (by size)", unit: "ea", hasDesc: true },
    { name: "Fernco couplings (by size)", unit: "ea", hasDesc: true },
    { name: "PVC pipe & fittings", unit: "ea", hasDesc: true },
    { name: "Primer & cement", unit: "ea", hasDesc: true },
    { name: "Sawzall blades", unit: "ea", hasDesc: true },
    { name: "Silicone / caulk", unit: "ea", hasDesc: true }
  ]},
  { title: "Consumables & PPE", items: [
    { name: "Nitrile gloves (boxes)", unit: "box", hasDesc: true },
    { name: "Respirator cartridges", unit: "ea" },
    { name: "Safety glasses", unit: "ea" },
    { name: "Duct / gorilla tape", unit: "roll" },
    { name: "Thick blue tape", unit: "roll" },
    { name: "Thin blue tape", unit: "roll" },
    { name: "Electrical tape", unit: "roll" },
    { name: "Zip ties", unit: "bag" },
    { name: "Plastic sheeting / drop cloths", unit: "roll" },
    { name: "Ram Board", unit: "roll" },
    { name: "Acetone", unit: "gal" },
    { name: "Vinegar", unit: "gal" },
    { name: "Simple Green", unit: "gal" },
    { name: "Baby powder", unit: "ea" },
    { name: "Rags / absorbent pads", unit: "ea" },
    { name: "Trash bags", unit: "box" }
  ]}
];
